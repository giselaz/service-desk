sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"itsm/tickets/tickets/test/integration/pages/OperationsList.gen",
	"itsm/tickets/tickets/test/integration/pages/OperationsObjectPage.gen"
], function (JourneyRunner, OperationsListGenerated, OperationsObjectPageGenerated) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('itsm/tickets/tickets') + '/test/flp.html#app-preview',
        pages: {
			onTheOperationsListGenerated: OperationsListGenerated,
			onTheOperationsObjectPageGenerated: OperationsObjectPageGenerated
        },
        async: true
    });

    return runner;
});

