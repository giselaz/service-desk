sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("itsm.tickets.tickets.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);